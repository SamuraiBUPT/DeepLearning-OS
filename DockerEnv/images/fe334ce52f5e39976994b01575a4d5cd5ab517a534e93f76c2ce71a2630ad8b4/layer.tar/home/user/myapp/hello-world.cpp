#include <iostream>
using namespace std;

int main () {
	cout << "Hello World!" << endl;
	cout << "Welcome to Docker + VSCode + C++ Env." << endl;
	return 0;
}